package sbu.common;

/**
  an enum for handling gender, default gender is not_say (which is stand for prefer not to say option)
**/
public enum Gender {
    MAN,WOMAN,NON_BINARY,NOT_SAY
}
