package sbu.common;

/**
  an enum for handling where is user in main menu
  for gettting mails list, program use this enum
**/
public enum MailFolder {
  INBOX,
  SENT,
  OUTBOX,
  TRASH,
  SEARCH
}
